"""Global constants for finding the path"""
import os.path
JSON_FILES_PATH = os.path.join(os.path.dirname(__file__),"../../../unittest/JSONFiles/")
JSON_FILES_GUEST_ARRIVAL = JSON_FILES_PATH + "/guestarrival/"
